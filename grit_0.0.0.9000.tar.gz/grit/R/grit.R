#' grit
#'
#' A package designed to document the analysis of repeatedly measured grit scores on the same subjects in different contexts
#'
#'
#' @docType package
#' @name grit
NULL